Readme:
------------

Dear buyer,


This is my personal thanks for purchasing this theme. You have helped me donate $1 from this purchased theme to a non profit organization named nisacanada.org. Nisacanada.org helped many women in North America, providing them shelter from distress and humilation, offering relief from frustration and desperation through proper care, housing and providing emergency care for women and families in crisis.

Please don't forget to rate this theme and hope you will purchase more themes from us in the near future.


With many thanks! 

God bless,

MyOrange

PS. If you are unhappy with the product please email me and I will try to do whatever I can to help you overcome any issues you are facing with this theme. 